# Pretty GPT

## ChatGPT background color switcher

![Alt Text](images/idea.png)

## How to setup

#### 1) Clone repo

```bash
git clone https://github.com/darakcheev00/prettyGpt
```

#### 2) Open Chrome extension manager
[chrome://extensions/](chrome://extensions/)

#### 3) Click "Load unpacked" and open the repo folder

![Alt Text](images/loadunpacked.png)

#### 4) Open ChatGPT and select background color from extension popup
[https://chat.openai.com/](https://chat.openai.com/)

![Alt Text](images/ss.png)

See ChatGPT change color:

![Alt Text](images/gpt.png)
